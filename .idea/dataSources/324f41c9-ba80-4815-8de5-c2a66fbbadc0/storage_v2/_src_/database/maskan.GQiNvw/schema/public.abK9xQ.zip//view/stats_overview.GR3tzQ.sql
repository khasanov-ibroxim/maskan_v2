create view stats_overview
            (active_users, active_sessions, total_objects, objects_waiting, objects_posted, logs_last_24h) as
SELECT (SELECT count(*) AS count
        FROM users
        WHERE users.is_active = true)                                                 AS active_users,
       (SELECT count(*) AS count
        FROM sessions
        WHERE sessions.is_active = true)                                              AS active_sessions,
       (SELECT count(*) AS count
        FROM objects)                                                                 AS total_objects,
       (SELECT count(*) AS count
        FROM objects
        WHERE objects.elon_status::text = 'waiting'::text)                            AS objects_waiting,
       (SELECT count(*) AS count
        FROM objects
        WHERE objects.elon_status::text = 'posted'::text)                             AS objects_posted,
       (SELECT count(*) AS count
        FROM activity_logs
        WHERE activity_logs."timestamp" > (CURRENT_TIMESTAMP - '24:00:00'::interval)) AS logs_last_24h;

alter table stats_overview
    owner to postgres;


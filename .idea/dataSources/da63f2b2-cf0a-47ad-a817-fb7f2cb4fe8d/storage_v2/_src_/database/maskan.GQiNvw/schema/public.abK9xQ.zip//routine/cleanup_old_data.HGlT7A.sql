create function cleanup_old_data() returns void
    language plpgsql
as
$$
BEGIN
    -- Delete sessions older than 30 days
    DELETE FROM sessions 
    WHERE logout_time IS NOT NULL 
    AND logout_time < CURRENT_TIMESTAMP - INTERVAL '30 days';
    
    -- Delete activity logs older than 90 days
    DELETE FROM activity_logs 
    WHERE timestamp < CURRENT_TIMESTAMP - INTERVAL '90 days';
    
    RAISE NOTICE 'Cleanup completed at %', CURRENT_TIMESTAMP;
END;
$$;

alter function cleanup_old_data() owner to postgres;


create view active_sessions
            (session_id, user_id, username, full_name, role, login_time, last_activity, ip_address, idle_seconds) as
SELECT s.session_id,
       s.user_id,
       s.username,
       u.full_name,
       u.role,
       s.login_time,
       s.last_activity,
       s.ip_address,
       EXTRACT(epoch FROM CURRENT_TIMESTAMP - s.last_activity)::integer AS idle_seconds
FROM sessions s
         JOIN users u ON s.user_id = u.id
WHERE s.is_active = true
ORDER BY s.last_activity DESC;

alter table active_sessions
    owner to postgres;


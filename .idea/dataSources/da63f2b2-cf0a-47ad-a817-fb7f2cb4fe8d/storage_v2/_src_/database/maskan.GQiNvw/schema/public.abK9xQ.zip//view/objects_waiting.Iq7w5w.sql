create view objects_waiting(id, unique_id, kvartil, xet, tell, narx, rieltor, created_at) as
SELECT id,
       unique_id,
       kvartil,
       xet,
       tell,
       narx,
       rieltor,
       created_at
FROM objects
WHERE elon_status::text = 'waiting'::text
ORDER BY created_at;

alter table objects_waiting
    owner to postgres;

